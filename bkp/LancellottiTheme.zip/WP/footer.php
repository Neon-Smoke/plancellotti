<footer>Copyright - 2021 - NeonGray</footer>
	</div>
</body>
<script src="main.js"></script>
</html>